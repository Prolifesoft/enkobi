<?php 
get_header();

do_action( 'cubewp/theme_builder/404' );

get_footer();
?>